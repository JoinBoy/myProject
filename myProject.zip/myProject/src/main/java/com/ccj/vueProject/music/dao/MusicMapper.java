package com.ccj.vueProject.music.dao;

import com.ccj.vueProject.music.bean.MusicBean;

public interface MusicMapper {
	public int addMusic(MusicBean musicbean);
}
