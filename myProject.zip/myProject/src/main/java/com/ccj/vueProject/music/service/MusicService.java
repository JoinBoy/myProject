package com.ccj.vueProject.music.service;

import com.ccj.vueProject.music.bean.MusicBean;

public interface MusicService {
	public int addMusic(MusicBean musicBean);
}
