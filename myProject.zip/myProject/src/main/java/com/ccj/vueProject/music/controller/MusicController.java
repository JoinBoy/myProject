package com.ccj.vueProject.music.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.ccj.vueProject.music.bean.MusicBean;
import com.ccj.vueProject.music.service.MusicService;
@Controller
public class MusicController {
	@Autowired
	public MusicService musicService;
	public void addMusicController(){
		MusicBean musicBean = new MusicBean();
		musicBean.setSongerId("1");
		musicBean.setSongerName("张聪");
		musicBean.setMusicId("2");
		musicBean.setMusicName("春天里");
		
		musicBean.setMusicUrl("播放地址");
		System.out.println(musicBean.toString());		
		int a = musicService.addMusic(musicBean);
		System.out.println(a);
	}
	
	public static void main(String[] args){
		MusicController a = new MusicController();
		a.addMusicController();
	}
}
