package com.ccj.vueProject.index.bean;

import lombok.Data;

@Data
public class IndexBean {
	private String userId;
	private String bannerUrl;
	private String imgId;
}
